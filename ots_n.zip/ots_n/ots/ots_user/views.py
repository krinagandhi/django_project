import hashlib
from django.shortcuts import render, redirect
from django.http import HttpResponse
from . models import UserRegistration
from django.contrib import messages

# Create your views here.
def index(request):
    return render(request, 'home.html')

def register(request):
    return render(request, 'register.html')

def signup(request):
    if request.session.has_key('userEmail'):
        return redirect('/home')
    else:
        if request.method == "POST":
            if request.POST.get('userSignupBtn'):
                if request.POST.get('password') == request.POST.get('conformPassword'):
                    saverecord = UserRegistration()
                    saverecord.firstname = request.POST.get('firstName')
                    saverecord.lastname = request.POST.get('lastName')
                    saverecord.email = request.POST.get('email')
                    saverecord.password = hashlib.sha256(str.encode(request.POST.get('password'))).hexdigest()
                    saverecord.mobileNo = request.POST.get('mobileNo')
                    saverecord.address = request.POST.get('address')
                    
                    UserInfo = UserRegistration.objects.filter(email=request.POST['email'])
                    if UserInfo:
                        return render(request, 'register.html')
                    saverecord.save()
                    return redirect('/login')
            else:
                return render(request, 'register.html')


def login(request):
    if request.session.has_key('email'):
        return redirect('/home')
    else:
        if request.method == 'POST':
            if request.POST['userLoginBtn']:
                pwd  = hashlib.sha256(str.encode(request.POST.get('userPassword'))).hexdigest()
                print('password is',pwd)
                UserInfo = UserRegistration.objects.filter(email=request.POST['userName'],password=pwd)
                if UserInfo:
                    request.session['userEmail'] = request.POST['userName']
                    return render(request,'home.html',{'UserInfo':UserInfo})
                else:
                    return render(request, 'login.html',{'error':'1'})
            else:
                return render(request, 'login.html')
        else:
            return render(request, 'login.html')

def logout(request):
    del request.session['userEmail']
    return redirect('/login')

def about(request):
    return render(request, 'about.html')